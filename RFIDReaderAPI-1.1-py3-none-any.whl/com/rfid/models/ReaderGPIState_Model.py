
# GPI状态/电平操作
class ReaderGPIState_Model:
    def __init__(self):
        self.dicState = {}
