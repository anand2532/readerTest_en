from enum import Enum

# EPC 基带参数 盘存标志参数
class ESearchType(Enum):
    FlagA = 0
    FlagB = 1
    FlagAB =2