from enum import Enum

# 输出开关
class EOutputSwitch(Enum):
    Close = 0
    Open = 1
    UDPOutput = 2