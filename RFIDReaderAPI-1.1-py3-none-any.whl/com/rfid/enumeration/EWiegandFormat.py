from enum import Enum


class EWiegandFormat(Enum):
    Wiegand26 = 0
    Wiegand34 = 1
    Wiegand66 = 2