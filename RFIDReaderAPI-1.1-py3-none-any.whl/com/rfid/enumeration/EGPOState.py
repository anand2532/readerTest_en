from enum import Enum


class EGPOState(Enum):
    _Low = 0
    _High = 1