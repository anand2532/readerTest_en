from enum import Enum


class EWorkMode(Enum):
    Server = 0
    Client = 1