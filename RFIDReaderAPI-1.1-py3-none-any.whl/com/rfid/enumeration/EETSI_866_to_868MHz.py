from enum import Enum


class EETSI_866_to_868MHz(Enum):
    _865_7f = 0
    _866_3f = 1
    _866_9f = 2
    _867_5f = 3
    _868_1f = 4