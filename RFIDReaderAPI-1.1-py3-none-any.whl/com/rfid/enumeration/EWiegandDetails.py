from enum import Enum


class EWiegandDetails(Enum):
    end_of_the_EPC_data = 0
    end_of_the_TID_data = 1