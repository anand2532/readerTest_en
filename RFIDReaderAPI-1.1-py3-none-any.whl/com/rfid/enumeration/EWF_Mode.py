from enum import Enum


class EWF_Mode(Enum):
    Specified = 0
    Auto = 1
