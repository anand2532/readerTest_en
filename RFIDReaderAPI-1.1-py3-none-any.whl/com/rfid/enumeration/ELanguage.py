from enum import Enum

# API语言包
class ELanguage(Enum):
    Chinese = 0
    English = 1