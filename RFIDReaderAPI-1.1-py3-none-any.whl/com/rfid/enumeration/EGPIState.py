from enum import Enum


class EGPIState(Enum):
    _Low =0
    _High = 1