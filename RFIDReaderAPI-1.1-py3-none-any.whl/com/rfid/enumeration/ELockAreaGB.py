from enum import Enum


class ELockAreaGB(Enum):
    tid = 0x00
    epc = 0x10
    Password = 0x20
    userdata00 = 0x30
    userdata01 = 0x31
    userdata02 = 0x32
    userdata03 = 0x33
    userdata04 = 0x34
    userdata05 = 0x35
    userdata06 = 0x36
    userdata07 = 0x37
    userdata08 = 0x38
    userdata09 = 0x39
    userdata10 = 0x3A
    userdata11 = 0x3B
    userdata12 = 0x3C
    userdata13 = 0x3D
    userdata14 = 0x3E
    userdata15 = 0x3F