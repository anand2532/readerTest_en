from enum import Enum

# 蜂鸣器 响的类型
class EBuzzerType(Enum):
    Once = 0
    Always = 1