from enum import Enum

#   回调枚举
class ECallBack(Enum):
    Tag = 0
    TagOver = 1
    CommandRec = 2
    GPIO = 9