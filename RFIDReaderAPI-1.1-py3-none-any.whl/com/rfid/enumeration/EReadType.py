from enum import Enum

#   读取类型
class EReadType(Enum):
    Single = 0
    Inventory = 1