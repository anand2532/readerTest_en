from enum import Enum

class EGPIO(Enum):
    _1 = 0
    _2 = 1
    _3 = 2
    _4 = 3